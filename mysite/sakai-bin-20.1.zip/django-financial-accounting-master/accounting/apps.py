# Copyright (c) 2015-2020 Data King Ltd
# See LICENSE file for license details

from django.apps import AppConfig

class AccountingConfig(AppConfig):
    name = 'accounting'
