# Copyright (c) 2015-2020 Data King Ltd
# See LICENSE file for license details

default_app_config = 'accounting.apps.AccountingConfig'
